import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import ReactDOM from 'react-dom'
class App extends React.Component {
   constructor(props)
   {
     super(props);
      this.state={
        messge:"welcome"
      }
   }

}



export default App;


 







